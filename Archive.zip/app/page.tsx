import CompactEvent from "@/components/CompactEvent";

export default function Home() {
  return (
    <main className="min-h-screen">
      <CompactEvent />
    </main>
  );
}
